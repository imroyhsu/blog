create
    definer = root@localhost function myf2(Ename varchar(20)) returns double
BEGIN
			SET @salary=0;
			SELECT e.salary INTO @salary
			FROM employees e
			WHERE e.last_name = Ename;
			
			RETURN @salary;
END;

