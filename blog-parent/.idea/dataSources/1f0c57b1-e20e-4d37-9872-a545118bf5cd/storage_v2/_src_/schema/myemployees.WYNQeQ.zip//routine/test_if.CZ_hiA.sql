create
    definer = root@localhost function test_if(score int) returns char
BEGIN
			IF score >= 90 AND score <=100 THEN RETURN 'A';
			ELSEIF score >=80 THEN return 'B';
			elseif score >=70 then return 'C';
			else return 'D';
			END IF ;
END;

