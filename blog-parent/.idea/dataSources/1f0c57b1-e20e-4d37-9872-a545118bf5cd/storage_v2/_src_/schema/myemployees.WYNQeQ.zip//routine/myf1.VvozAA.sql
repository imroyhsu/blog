create
    definer = root@localhost function myf1() returns int
BEGIN
			DECLARE num INT DEFAULT 0;
			SELECT COUNT(*) INTO num
			FROM employees;
			
			RETURN num;
END;

