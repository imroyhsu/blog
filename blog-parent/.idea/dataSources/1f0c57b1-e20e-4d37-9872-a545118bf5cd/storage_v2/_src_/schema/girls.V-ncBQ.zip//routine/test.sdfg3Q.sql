create
    definer = root@localhost procedure test(IN count int)
begin
			DECLARE i INT DEFAULT 1;
			a:WHILE (i<=count) DO
	INSERT INTO admin(username, `password`) values (CONCAT('asdad',i), '31231');
	IF i>=20 then LEAVE a;
	end IF;
	set i = i+1;
END WHILE;

END;

