create
    definer = root@localhost procedure myp3(INOUT a int, INOUT b int)
begin
			SET a= a*2;
			SET b= b*2;
END;

