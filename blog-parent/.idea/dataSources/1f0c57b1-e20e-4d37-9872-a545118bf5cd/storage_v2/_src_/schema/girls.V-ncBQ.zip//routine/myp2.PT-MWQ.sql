create
    definer = root@localhost procedure myp2(IN beautyName varchar(20), OUT boyName varchar(20), OUT cp int)
begin
			SELECT bo.boyName , bo.userCP INTO  boyName, cp
			FROM boys bo
			INNER JOIN beauty b ON bo.id = b.boyfriend_id
			WHERE b.`name` = beautyName;
END;

